package com.krypton;

import com.krypton.gui.ClickGui;
import com.krypton.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class KryptonClient implements ClientModInitializer {
    public static ModuleManager modules;
    public static ClickGui gui;
    private static KeyBinding openGui;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        modules.init();
        gui = new ClickGui();

        openGui = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.krypton.clickgui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_RIGHT_SHIFT,
                "Krypton"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGui.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(gui);
                }
            }
            modules.tick(client);
        });
    }
}
