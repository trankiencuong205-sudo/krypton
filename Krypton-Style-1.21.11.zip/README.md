# Krypton Style Client — Minecraft 1.21.11

Project tham khảo theo cấu trúc client/menu Krypton mà bạn mô tả.

## Có
- Fabric 1.21.11
- ClickGUI
- COMBAT / MOVEMENT / RENDER / WORLD / MISC
- BaseFinder
- StashFinder
- NewChunks
- StorageESP
- ESP
- ModuleManager
- Right Shift mở GUI
- Panel kéo bằng chuột trái
- Chuột phải header để thu gọn/mở
- Click module để bật/tắt

## Reference
AutoDupe và PacketDupe được giữ tên trong module list để mô phỏng cấu trúc giao diện, nhưng không chứa logic khai thác lỗi/nhân đồ.

## Build
Dùng Java 21 cho Minecraft 1.21.x.

    ./gradlew build

JAR sẽ nằm trong:
    build/libs/
