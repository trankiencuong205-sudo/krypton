package com.krypton.gui;

import com.krypton.KryptonClient;
import com.krypton.module.Category;
import com.krypton.module.Module;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;

public class ClickGui extends Screen {
    private static final int PANEL_W = 132;
    private static final int HEADER_H = 20;
    private static final int ROW_H = 17;

    private final int[] panelX = {18, 160, 302, 444, 586};
    private final int[] panelY = {30, 30, 30, 30, 30};
    private final boolean[] expanded = {true, true, true, true, true};

    private int dragging = -1;
    private int offsetX;
    private int offsetY;

    public ClickGui() {
        super(Text.literal("Krypton"));
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x99070A10);

        Category[] categories = Category.values();

        for (int i = 0; i < categories.length; i++) {
            int x = panelX[i];
            int y = panelY[i];

            if (dragging == i) {
                x = mouseX - offsetX;
                y = mouseY - offsetY;
                panelX[i] = x;
                panelY[i] = y;
            }

            drawPanel(ctx, categories[i], x, y, expanded[i]);
        }

        ctx.drawText(textRenderer, "KRYPTON  •  1.21.11", 18, height - 24, 0xFFB8C7FF, false);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawPanel(DrawContext ctx, Category category, int x, int y, boolean open) {
        ctx.fill(x, y, x + PANEL_W, y + HEADER_H, 0xFF1A1D28);
        ctx.drawText(textRenderer, category.name(), x + 7, y + 6, 0xFFFFFFFF, false);

        if (!open) return;

        int row = 0;
        for (Module module : KryptonClient.modules.getModules()) {
            if (module.getCategory() != category) continue;

            int yy = y + HEADER_H + row * ROW_H;
            int bg = module.isEnabled() ? 0xFF304E3A : 0xFF252832;
            int fg = module.isEnabled() ? 0xFF78FF9B : 0xFFD7D9E0;

            ctx.fill(x, yy, x + PANEL_W, yy + ROW_H, bg);
            ctx.drawText(textRenderer, module.getName(), x + 7, yy + 4, fg, false);
            row++;
        }

        ctx.fill(x, y + HEADER_H + row * ROW_H,
                x + PANEL_W, y + HEADER_H + row * ROW_H + 1, 0xFF111218);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x(), mouseY = click.y();
        int button = click.button();
        Category[] categories = Category.values();

        for (int i = 0; i < categories.length; i++) {
            int x = panelX[i];
            int y = panelY[i];

            if (mouseX >= x && mouseX <= x + PANEL_W &&
                mouseY >= y && mouseY <= y + HEADER_H) {

                if (button == 0) {
                    dragging = i;
                    offsetX = (int) mouseX - x;
                    offsetY = (int) mouseY - y;
                } else if (button == 1) {
                    expanded[i] = !expanded[i];
                }
                return true;
            }

            if (!expanded[i]) continue;

            int row = (int)((mouseY - y - HEADER_H) / ROW_H);
            if (row < 0 || mouseX < x || mouseX > x + PANEL_W) continue;

            int seen = 0;
            for (Module module : KryptonClient.modules.getModules()) {
                if (module.getCategory() != categories[i]) continue;

                if (seen == row) {
                    if (button == 0) module.toggle();
                    return true;
                }
                seen++;
            }
        }

        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (click.button() == 0) dragging = -1;
        return super.mouseReleased(click);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
