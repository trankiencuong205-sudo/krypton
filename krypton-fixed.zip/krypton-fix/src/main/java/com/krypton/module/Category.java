package com.krypton.module;

public enum Category {
    COMBAT, MOVEMENT, RENDER, WORLD, MISC
}
