package com.krypton.module;

import net.minecraft.client.MinecraftClient;

public abstract class Module {
    private final String name;
    private final Category category;
    private boolean enabled;

    protected Module(String name, Category category) {
        this.name = name;
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public Category getCategory() {
        return category;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void toggle() {
        enabled = !enabled;
        if (enabled) onEnable();
        else onDisable();
    }

    public void tick(MinecraftClient client) {
        if (enabled) onTick(client);
    }

    protected void onEnable() {}
    protected void onDisable() {}
    protected void onTick(MinecraftClient client) {}
}
