package com.krypton.module;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ModuleManager {
    private final List<Module> modules = new ArrayList<>();

    public void init() {
        modules.clear();

        add("KillAura", Category.COMBAT);
        add("Surround", Category.COMBAT);
        add("AutoCrystal", Category.COMBAT);

        add("Speed", Category.MOVEMENT);
        add("Fly", Category.MOVEMENT);
        add("NoFall", Category.MOVEMENT);

        add("ESP", Category.RENDER);
        add("StorageESP", Category.RENDER);

        add("BaseFinder", Category.WORLD);
        add("StashFinder", Category.WORLD);
        add("NewChunks", Category.WORLD);
        add("PacketMine", Category.WORLD);

        add("AutoDupe (Reference)", Category.MISC);
        add("PacketDupe (Reference)", Category.MISC);
        add("Config", Category.MISC);
    }

    private void add(String name, Category category) {
        modules.add(new ReferenceModule(name, category));
    }

    public void tick(MinecraftClient client) {
        for (Module module : modules) {
            module.tick(client);
        }
    }

    public List<Module> getModules() {
        return Collections.unmodifiableList(modules);
    }

    private static final class ReferenceModule extends Module {
        private ReferenceModule(String name, Category category) {
            super(name, category);
        }
    }
}
